function App() {
  return (
    <div className="h-screen bg-gray-100 flex justify-center items-center">
      <h1 className="text-4xl font-bold text-blue-600">AI Bug Predictor</h1>
    </div>
  );
}

export default App;
